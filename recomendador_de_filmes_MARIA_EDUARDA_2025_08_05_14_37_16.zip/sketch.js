let campoIdade;
let campoFantasia;
let campoAventura;

function setup() {
  createCanvas(800, 400);
  createElement("h2", "Recomendador de filmes para 10 a 14 anos!");
  createSpan("Sua idade:");
  campoIdade = createInput("5");
  campoFantasia = createCheckbox("Gosta de fantasia?");
  campoAventura = createCheckbox("Gosta de aventura?");
}

function draw() {
  background("#CA71DA");
  let idade = campoIdade.value();
  let gostaDeFantasia = campoFantasia.checked();
  let gostaDeAventura = campoAventura.checked();
  let recomendacao = geraRecomendacao(idade, gostaDeFantasia, gostaDeAventura);

  fill(color(76, 0, 115));
  textAlign(CENTER, CENTER);
  textSize(38);
  text(recomendacao, width / 2, height / 2);
}

function geraRecomendacao(idade, gostaDeFantasia, gostaDeAventura) {
  if (idade >= 10) {
    if (idade >= 14) {
      return "O Incrível Mundo de Gumball";
    } else {
      if (idade >= 12) {
        if(gostaDeFantasia || gostaDeAventura) {
          return "Os Jovens Titãs em Ação";          
        } else{
         return "Miraculous: As Aventuras de Ladybug";
        }
      } else {
        if (gostaDeFantasia) {
          return "Irmão do Jorel";
        } else {
          return "Lilo & Stitch";
        }
      }
    }
  } else {
    if (gostaDeFantasia) {
      return "As Aventuras do Gato de Botas";
    } else {
      return "Tom e Jerry";
    }
  }
}

